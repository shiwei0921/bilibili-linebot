import { HashRouter as Router, Routes, Route, useNavigate, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Followlist from "./followlist";
import "./App.css";
import Pricesearch from "./pricesearch";
import Pnlbalance from "./pnlbalance";
import Trade from "./trade";
import Reset from "./reset";

// 首頁元件
function Home() {
  const navigate = useNavigate();
  const location = useLocation();

  // ✅ 初始化 user_id（從網址參數或 localStorage）
  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const incomingId = queryParams.get("user_id");

    if (incomingId) {
      localStorage.setItem("user_id", incomingId);
      console.log("✅ 設定 user_id：", incomingId);

      // ✅ 傳送 user_id 給後端
      fetch("/set_uid", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uid: incomingId })
      })
        .then(res => res.json())
        .then(data => console.log("✅ 傳送 UID 給後端成功", data))
        .catch(err => console.error("❌ 傳送 UID 錯誤", err));
    } else {
      const savedId = localStorage.getItem("user_id");
      if (!savedId) {
        localStorage.setItem("user_id", "test_user_001");
        console.log("🔧 使用預設 user_id：test_user_001");
      }
    }

    // ❌❌ 不要在這裡根據 hash 跳轉 ❌❌
    // const hash = window.location.hash;
    // if (hash === "#/followlist") navigate("/followlist");
    // ...
  }, []);

  return (
    <div>
      <h1 className="title">幣哩幣哩</h1>
      <div className="crypto-glass home">
        <div className="main-buttons">
          <button type="button" className="glass-btn" onClick={() => navigate("/followlist")}>追蹤清單</button>
          <button type="button" className="glass-btn" onClick={() => navigate("/pricesearch")}>幣價查詢</button>
          <button type="button" className="glass-btn" onClick={() => navigate("/pnlbalance")}>損益&餘額查詢</button>
          <button type="button" className="glass-btn" onClick={() => navigate("/trade")}>Trade</button>
          <button type="button" className="glass-btn danger" onClick={() => navigate("/reset")}>重置</button>
        </div>
      </div>
    </div>
  );
}

// App 主入口（路由控制）
export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/followlist" element={<Followlist />} />
        <Route path="/pricesearch" element={<Pricesearch />} />
        <Route path="/pnlbalance" element={<Pnlbalance />} />
        <Route path="/trade" element={<Trade />} />
        <Route path="/reset" element={<Reset />} />
      </Routes>
    </Router>
  );
}
